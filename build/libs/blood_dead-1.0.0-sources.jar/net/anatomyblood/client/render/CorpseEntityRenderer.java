package net.anatomyblood.client.render;

import com.mojang.authlib.GameProfile;
import net.anatomyblood.entity.CorpseEntity;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10055;
import net.minecraft.class_1068;
import net.minecraft.class_156;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5602;
import net.minecraft.class_5617;
import net.minecraft.class_591;
import net.minecraft.class_634;
import net.minecraft.class_640;
import net.minecraft.class_7833;
import net.minecraft.class_8685;
import net.minecraft.class_897;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

@Environment(EnvType.CLIENT)
public class CorpseEntityRenderer extends class_897<CorpseEntity, CorpseRenderState> {
    private final class_591 modelWide;
    private final class_591 modelSlim;
    private final class_10055 playerRenderState = new class_10055();
    private static final Map<UUID, class_8685> SKIN_CACHE = new ConcurrentHashMap<>();

    public CorpseEntityRenderer(class_5617.class_5618 context) {
        super(context);
        this.modelWide = new class_591(context.method_32167(class_5602.field_27577), false);
        this.modelSlim = new class_591(context.method_32167(class_5602.field_27581), true);
        this.field_4673 = 0.5f;

        // Force initialize playerRenderState boolean flags for outer skin layers
        this.playerRenderState.field_53543 = true;
        this.playerRenderState.field_53544 = true;
        this.playerRenderState.field_53530 = true;
        this.playerRenderState.field_53531 = true;
        this.playerRenderState.field_53545 = true;
        this.playerRenderState.field_53546 = true;
    }

    @Override
    public CorpseRenderState method_55269() {
        return new CorpseRenderState();
    }

    @Override
    public void updateRenderState(CorpseEntity entity, CorpseRenderState state, float tickDelta) {
        super.method_62354(entity, state, tickDelta);
        state.yaw = entity.method_36454();
        state.playerUuid = entity.getPlayerUuid().orElse(class_156.field_25140);
        state.playerName = entity.getPlayerName();
        state.ragdoll = entity.getRagdoll();
        state.draggingPlayerUuid = entity.getDraggingPlayerUuid().orElse(null);
    }

    private class_8685 getSkinTextures(UUID uuid, String name) {
        if (uuid == null || uuid.equals(class_156.field_25140)) {
            return class_1068.method_4648(class_156.field_25140);
        }

        class_8685 cached = SKIN_CACHE.get(uuid);
        if (cached != null) {
            return cached;
        }

        class_634 networkHandler = class_310.method_1551().method_1562();
        if (networkHandler != null) {
            class_640 entry = networkHandler.method_2871(uuid);
            if (entry != null) {
                class_8685 textures = entry.method_52810();
                if (textures != null) {
                    SKIN_CACHE.put(uuid, textures);
                    return textures;
                }
            }
        }

        GameProfile profile = new GameProfile(uuid, name);
        class_8685 textures = class_310.method_1551().method_1582().method_52862(profile);
        if (textures != null) {
            class_310.method_1551().method_1582().method_52863(profile).thenAccept(optionalSkin -> {
                optionalSkin.ifPresent(s -> SKIN_CACHE.put(uuid, s));
            });
            return textures;
        }

        return class_1068.method_4648(uuid);
    }

    @Override
    public void render(CorpseRenderState state, class_4587 matrixStack, class_4597 vertexConsumers, int light) {
        matrixStack.method_22903();

        // Position model lying flat horizontal on the ground imitating an inert corpse
        matrixStack.method_22904(0.0D, 0.2D, 0.0D);
        matrixStack.method_22907(class_7833.field_40716.rotationDegrees(180.0F - state.yaw));
        matrixStack.method_22907(class_7833.field_40714.rotationDegrees(90.0F));
        matrixStack.method_22904(0.0D, -0.6D, 0.1D);

        // Fetch skin textures for player profile
        UUID playerUuid = state.playerUuid != null ? state.playerUuid : class_156.field_25140;
        String playerName = state.playerName != null ? state.playerName : "";

        class_8685 skinTextures = getSkinTextures(playerUuid, playerName);
        class_2960 texture = skinTextures.comp_1626();
        class_591 model = (skinTextures.comp_1629() == class_8685.class_7920.field_41122) ? this.modelSlim : this.modelWide;

        // Force model parts visibility
        model.field_3398.field_3665 = true;
        model.field_3394.field_3665 = true;
        model.field_3391.field_3665 = true;
        model.field_3401.field_3665 = true;
        model.field_27433.field_3665 = true;
        model.field_3392.field_3665 = true;
        model.field_3397.field_3665 = true;

        // Dynamic Jolt Ragdoll joint posture angles for fallen corpse
        net.anatomyblood.physics.JoltRagdoll ragdoll = state.ragdoll;
        if (ragdoll != null) {
            model.field_3398.field_3654 = ragdoll.headPitch;
            model.field_3398.field_3675 = ragdoll.headYaw;
            model.field_3398.field_3674 = ragdoll.headRoll;

            model.field_3401.field_3654 = ragdoll.rightArmPitch;
            model.field_3401.field_3675 = ragdoll.rightArmYaw;
            model.field_3401.field_3674 = ragdoll.rightArmRoll;

            model.field_27433.field_3654 = ragdoll.leftArmPitch;
            model.field_27433.field_3675 = ragdoll.leftArmYaw;
            model.field_27433.field_3674 = ragdoll.leftArmRoll;

            model.field_3392.field_3654 = ragdoll.rightLegPitch;
            model.field_3392.field_3675 = ragdoll.rightLegYaw;
            model.field_3392.field_3674 = ragdoll.rightLegRoll;

            model.field_3397.field_3654 = ragdoll.leftLegPitch;
            model.field_3397.field_3675 = ragdoll.leftLegYaw;
            model.field_3397.field_3674 = ragdoll.leftLegRoll;

            model.field_3391.field_3654 = ragdoll.bodyPitch;
            model.field_3391.field_3675 = ragdoll.bodyYaw;
            model.field_3391.field_3674 = ragdoll.bodyRoll;
        }

        // Force copy transforms to outer skin layers (hat, jacket, sleeves, pants)
        // Bypasses any pose resets from animation mods (Not Enough Animations / EMF)
        model.field_3394.method_17138(model.field_3398);
        model.field_3483.method_17138(model.field_3391);
        model.field_3486.method_17138(model.field_3401);
        model.field_3484.method_17138(model.field_27433);
        model.field_3479.method_17138(model.field_3392);
        model.field_3482.method_17138(model.field_3397);

        class_4588 vertexConsumer = vertexConsumers.getBuffer(class_1921.method_23578(texture));
        model.method_60879(matrixStack, vertexConsumer, light, class_4608.field_21444);

        matrixStack.method_22909();
        super.method_3936(state, matrixStack, vertexConsumers, light);
    }
}
