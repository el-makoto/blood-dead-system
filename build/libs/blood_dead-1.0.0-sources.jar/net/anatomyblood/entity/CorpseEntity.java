package net.anatomyblood.entity;

import net.anatomyblood.AnatomyOfBlood;
import net.anatomyblood.particle.ModParticles;
import net.anatomyblood.util.BloodConstants;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1313;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2400;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2604;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3218;
import net.minecraft.class_3231;
import java.util.Optional;
import java.util.UUID;

public class CorpseEntity extends class_1297 {
    private static final class_2940<Optional<UUID>> PLAYER_UUID = class_2945.method_12791(CorpseEntity.class, class_2943.field_13313);
    private static final class_2940<String> PLAYER_NAME = class_2945.method_12791(CorpseEntity.class, class_2943.field_13326);
    private static final class_2940<Optional<UUID>> DRAGGING_PLAYER_UUID = class_2945.method_12791(CorpseEntity.class, class_2943.field_13313);

    public CorpseEntity(class_1299<?> type, class_1937 world) {
        super(type, world);
        this.field_23807 = true;
    }

    @Override
    protected void method_5693(class_2945.class_9222 builder) {
        builder.method_56912(PLAYER_UUID, Optional.empty());
        builder.method_56912(PLAYER_NAME, "");
        builder.method_56912(DRAGGING_PLAYER_UUID, Optional.empty());
    }

    public void setPlayerUuid(UUID uuid) {
        this.field_6011.method_12778(PLAYER_UUID, Optional.ofNullable(uuid));
    }

    public Optional<UUID> getPlayerUuid() {
        return this.field_6011.method_12789(PLAYER_UUID);
    }

    public void setPlayerName(String name) {
        this.field_6011.method_12778(PLAYER_NAME, name == null ? "" : name);
    }

    public String getPlayerName() {
        return this.field_6011.method_12789(PLAYER_NAME);
    }

    public void setDraggingPlayerUuid(UUID uuid) {
        this.field_6011.method_12778(DRAGGING_PLAYER_UUID, Optional.ofNullable(uuid));
    }

    public Optional<UUID> getDraggingPlayerUuid() {
        return this.field_6011.method_12789(DRAGGING_PLAYER_UUID);
    }

    @Override
    public class_1269 method_5688(class_1657 player, class_1268 hand) {
        if (hand == class_1268.field_5808 && player.method_6047().method_7960()) {
            if (!this.method_37908().method_8608()) {
                Optional<UUID> current = getDraggingPlayerUuid();
                if (current.isPresent() && current.get().equals(player.method_5667())) {
                    setDraggingPlayerUuid(null);
                    player.method_7353(class_2561.method_43470("§cSoltaste el cadáver."), true);
                } else if (current.isEmpty()) {
                    setDraggingPlayerUuid(player.method_5667());
                    player.method_7353(class_2561.method_43470("§aArrastrando cadáver..."), true);
                }
            }
            return class_1269.field_5812;
        }
        return super.method_5688(player, hand);
    }

    @Override
    public boolean method_64397(class_3218 world, class_1282 source, float amount) {
        return false;
    }

    private net.anatomyblood.physics.JoltRagdoll ragdoll;

    public net.anatomyblood.physics.JoltRagdoll getRagdoll() {
        if (ragdoll == null) {
            ragdoll = new net.anatomyblood.physics.JoltRagdoll(this.method_18798(), this.method_36454());
        }
        return ragdoll;
    }

    @Override
    public void method_5773() {
        super.method_5773();

        // Step Jolt Physics ragdoll simulation
        getRagdoll().tick(this.method_24828(), this.method_18798());

        // Server-only physics logic to prevent client-side desync & void clipping
        if (!this.method_37908().method_8608()) {
            Optional<UUID> draggingUuid = getDraggingPlayerUuid();
            if (draggingUuid.isPresent()) {
                class_3218 serverWorld = (class_3218) this.method_37908();
                class_1657 draggingPlayer = serverWorld.method_18470(draggingUuid.get());

                if (draggingPlayer == null || !draggingPlayer.method_5805() || draggingPlayer.method_5858(this) > 36.0D) {
                    setDraggingPlayerUuid(null);
                } else {
                    // Pull corpse smoothly behind player
                    class_243 look = draggingPlayer.method_5720();
                    class_243 target = draggingPlayer.method_19538().method_1023(look.field_1352 * 1.2D, 0.0D, look.field_1350 * 1.2D);
                    class_243 diff = target.method_1020(this.method_19538());

                    this.method_18800(diff.field_1352 * 0.4D, Math.max(-0.2D, diff.field_1351 * 0.4D), diff.field_1350 * 0.4D);
                    this.method_5784(class_1313.field_6308, this.method_18798());

                    // Dragging blood trail particle (#F0509A)
                    if (this.field_6012 % 4 == 0) {
                        boolean despawnBlood = AnatomyOfBlood.shouldDespawnBlood(serverWorld);
                        class_2400 stainParticle = despawnBlood ? ModParticles.BLOOD_STAIN_TEMPORARY : ModParticles.BLOOD_STAIN_PERMANENT;

                        serverWorld.method_65096(stainParticle, method_23317(), method_23318() + 0.05D, method_23321(), 2, 0.2D, 0.0D, 0.2D, 0.0D);
                        serverWorld.method_65096(ModParticles.BLOOD_DRIP, method_23317(), method_23318() + 0.2D, method_23321(), 3, 0.1D, 0.1D, 0.1D, 0.05D);
                    }
                }
            } else if (this.method_5799()) {
                // Water buoyancy and flow physics
                class_243 vel = this.method_18798();
                this.method_18800(vel.field_1352 * 0.9D, Math.min(0.05D, vel.field_1351 + 0.02D), vel.field_1350 * 0.9D);
                this.method_5784(class_1313.field_6308, this.method_18798());
            } else if (!this.method_5740()) {
                class_243 vel = this.method_18798();
                double newY = this.method_24828() ? 0.0D : Math.max(-0.98D, vel.field_1351 - 0.08D);

                double newX = this.method_24828() ? vel.field_1352 * 0.8D : vel.field_1352 * 0.98D;
                double newZ = this.method_24828() ? vel.field_1350 * 0.8D : vel.field_1350 * 0.98D;

                this.method_18800(newX, newY, newZ);
                this.method_5784(class_1313.field_6308, this.method_18798());

                if (this.method_24828() || this.field_5992) {
                    this.method_18800(this.method_18798().field_1352, 0.0D, this.method_18798().field_1350);
                }
            }
        }
    }

    @Override
    public class_2596<class_2602> method_18002(class_3231 entityTrackerEntry) {
        return new class_2604(this, entityTrackerEntry);
    }

    @Override
    public boolean method_31746() {
        return true;
    }

    @Override
    public boolean method_49108() {
        return true;
    }

    @Override
    public boolean method_30948() {
        return false; // Return false to prevent physics pushing forces from clipping corpse into solid blocks
    }

    @Override
    public void method_36209() {
        String env = this.method_37908().method_8608() ? "CLIENT" : "SERVER";
        BloodConstants.LOGGER.info("[{}] CorpseEntity for player '{}' ({}) was removed at pos {} from world. Reason: {}", env, getPlayerName(), getPlayerUuid().orElse(null), method_19538(), method_35049());
        super.method_36209();
    }

    @Override
    protected void method_5749(class_2487 nbt) {
        if (nbt.method_25928("PlayerUuid")) {
            setPlayerUuid(nbt.method_25926("PlayerUuid"));
        }
        if (nbt.method_10573("PlayerName", class_2520.field_33258)) {
            setPlayerName(nbt.method_10558("PlayerName"));
        }
        if (nbt.method_25928("DraggingPlayerUuid")) {
            setDraggingPlayerUuid(nbt.method_25926("DraggingPlayerUuid"));
        }
    }

    @Override
    protected void method_5652(class_2487 nbt) {
        getPlayerUuid().ifPresent(uuid -> nbt.method_25927("PlayerUuid", uuid));
        nbt.method_10582("PlayerName", getPlayerName());
        getDraggingPlayerUuid().ifPresent(uuid -> nbt.method_25927("DraggingPlayerUuid", uuid));
    }
}
