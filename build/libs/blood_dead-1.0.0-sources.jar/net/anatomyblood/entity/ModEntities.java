package net.anatomyblood.entity;

import net.anatomyblood.util.BloodConstants;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class ModEntities {
    public static final class_5321<class_1299<?>> CORPSE_KEY = class_5321.method_29179(
            class_7924.field_41266,
            class_2960.method_60655(BloodConstants.MOD_ID, "corpse")
    );

    public static final class_1299<CorpseEntity> CORPSE = class_2378.method_39197(
            class_7923.field_41177,
            CORPSE_KEY,
            class_1299.class_1300.<CorpseEntity>method_5903(CorpseEntity::new, class_1311.field_17715)
                    .method_17687(0.9f, 0.4f)
                    .method_27299(256)
                    .method_27300(1)
                    .method_5905(CORPSE_KEY)
    );

    public static void registerEntities() {
        BloodConstants.LOGGER.info("Registered Corpse entity for Anatomy of Blood.");
    }
}
