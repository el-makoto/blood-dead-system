package net.anatomyblood.mixin;

import net.anatomyblood.AnatomyOfBlood;
import net.anatomyblood.entity.CorpseEntity;
import net.anatomyblood.entity.ModEntities;
import net.anatomyblood.particle.ModParticles;
import net.anatomyblood.util.BloodConstants;
import net.minecraft.class_1282;
import net.minecraft.class_2400;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_8111;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;

@Mixin(class_3222.class)
public abstract class ServerPlayerEntityMixin {

    @Inject(method = "onDeath", at = @At("HEAD"))
    private void onServerPlayerDeath(class_1282 damageSource, CallbackInfo ci) {
        class_3222 player = (class_3222) (Object) this;
        class_3218 serverWorld = player.method_51469();

        double x = player.method_23317();
        double y = player.method_23318();
        double z = player.method_23321();

        boolean despawnBlood = AnatomyOfBlood.shouldDespawnBlood(serverWorld);
        class_2400 stainParticle = despawnBlood ? ModParticles.BLOOD_STAIN_TEMPORARY : ModParticles.BLOOD_STAIN_PERMANENT;

        // Spawn blood stain, drip, and splash particles at death location (#F0509A)
        serverWorld.method_65096(stainParticle, x, y + 0.05D, z, 20, 0.5D, 0.0D, 0.5D, 0.0D);
        serverWorld.method_65096(ModParticles.BLOOD_DRIP, x, y + 0.8D, z, 40, 0.4D, 0.4D, 0.4D, 0.15D);
        serverWorld.method_65096(ModParticles.BLOOD_SPLASH, x, y + 0.8D, z, 30, 0.5D, 0.5D, 0.5D, 0.25D);

        // On fall death: spawn massive blood particle burst
        if (damageSource.method_49708(class_8111.field_42345)) {
            serverWorld.method_65096(ModParticles.BLOOD_DRIP, x, y + (player.method_17682() / 2.0D), z, 160, 0.6D, 0.6D, 0.6D, 0.25D);
            serverWorld.method_65096(ModParticles.BLOOD_SPLASH, x, y + (player.method_17682() / 2.0D), z, 120, 0.8D, 0.8D, 0.8D, 0.4D);
        }

        // Spawn Corpse ragdoll entity with player's UUID, velocity and skin
        CorpseEntity corpse = new CorpseEntity(ModEntities.CORPSE, serverWorld);
        corpse.method_5808(x, y, z, player.method_36454(), player.method_36455());
        corpse.method_18799(player.method_18798()); // Inherit momentum for ragdoll physics
        corpse.setPlayerUuid(player.method_5667());
        corpse.setPlayerName(player.method_7334().getName());
        boolean spawned = serverWorld.method_8649(corpse);

        BloodConstants.LOGGER.info("Spawned CorpseEntity for {} at ({}, {}, {}). Success: {}", player.method_7334().getName(), x, y, z, spawned);
    }

    @Inject(method = "copyFrom", at = @At("HEAD"))
    private void onRespawnCopyFrom(class_3222 oldPlayer, boolean alive, CallbackInfo ci) {
        class_3222 player = (class_3222) (Object) this;
        class_3218 world = player.method_51469();
        BloodConstants.LOGGER.info("Player {} respawns. Corpse remains persistent in world.", player.method_7334().getName());
    }
}
