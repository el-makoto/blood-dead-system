package net.anatomyblood.mixin;

import net.anatomyblood.AnatomyOfBlood;
import net.anatomyblood.entity.CorpseEntity;
import net.anatomyblood.particle.ModParticles;
import net.minecraft.class_1282;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_2400;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;

@Mixin(class_1657.class)
public abstract class PlayerEntityMixin {

    @Inject(method = "damage", at = @At("HEAD"))
    private void onPlayerDamageReleaseCorpse(class_3218 world, class_1282 source, float amount, CallbackInfoReturnable<Boolean> cir) {
        class_1657 player = (class_1657) (Object) this;
        // When player receives damage, release any corpses currently being dragged
        class_238 box = player.method_5829().method_1014(32.0D);
        List<CorpseEntity> corpses = world.method_8390(CorpseEntity.class, box, c ->
                c.getDraggingPlayerUuid().map(uuid -> uuid.equals(player.method_5667())).orElse(false)
        );
        for (CorpseEntity corpse : corpses) {
            corpse.setDraggingPlayerUuid(null);
        }
    }

    @Inject(method = "tick", at = @At("TAIL"))
    private void onWoundedPlayerTick(CallbackInfo ci) {
        class_1657 player = (class_1657) (Object) this;

        if (!player.method_37908().method_8608() && player.method_37908() instanceof class_3218 serverWorld) {
            // Wounded blood trail: If health < 50% and player is moving, drop blood particles on ground
            if (player.method_6032() <= player.method_6063() * 0.5F && player.method_18798().method_1027() > 0.001D) {
                if (player.field_6012 % 10 == 0) {
                    boolean despawnBlood = AnatomyOfBlood.shouldDespawnBlood(serverWorld);
                    class_2400 stainParticle = despawnBlood ? ModParticles.BLOOD_STAIN_TEMPORARY : ModParticles.BLOOD_STAIN_PERMANENT;

                    double x = player.method_23317();
                    double y = player.method_23318() + 0.05D;
                    double z = player.method_23321();

                    serverWorld.method_65096(stainParticle, x, y, z, 2, 0.2D, 0.0D, 0.2D, 0.0D);
                    serverWorld.method_65096(ModParticles.BLOOD_DRIP, x, y + 0.5D, z, 3, 0.1D, 0.1D, 0.1D, 0.05D);
                }
            }
        }
    }
}
