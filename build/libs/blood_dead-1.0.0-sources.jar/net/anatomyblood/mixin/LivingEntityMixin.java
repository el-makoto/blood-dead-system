package net.anatomyblood.mixin;

import net.anatomyblood.particle.ModParticles;
import net.minecraft.class_1282;
import net.minecraft.class_1309;
import net.minecraft.class_3218;
import net.minecraft.class_8111;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1309.class)
public abstract class LivingEntityMixin {

    @Inject(method = "damage", at = @At("RETURN"))
    private void onDamage(class_3218 world, class_1282 source, float amount, CallbackInfoReturnable<Boolean> cir) {
        if (Boolean.TRUE.equals(cir.getReturnValue()) && source.method_49708(class_8111.field_42345)) {
            class_1309 entity = (class_1309) (Object) this;

            // Spawn blood particles proportional to fall damage amount (#F0509A)
            int dripCount = Math.max(6, (int) (amount * 8));
            int splashCount = Math.max(4, (int) (amount * 5));

            double x = entity.method_23317();
            double y = entity.method_23318() + (entity.method_17682() / 2.0D);
            double z = entity.method_23321();

            world.method_65096(ModParticles.BLOOD_DRIP, x, y, z, dripCount, 0.35D, 0.35D, 0.35D, 0.15D);
            world.method_65096(ModParticles.BLOOD_SPLASH, x, y, z, splashCount, 0.45D, 0.45D, 0.45D, 0.25D);
        }
    }
}
