package net.anatomyblood.particle;

import net.anatomyblood.util.BloodConstants;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2400;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_3999;
import net.minecraft.class_4002;
import net.minecraft.class_4003;
import net.minecraft.class_4184;
import net.minecraft.class_4588;
import net.minecraft.class_638;
import net.minecraft.class_703;
import net.minecraft.class_707;

@Environment(EnvType.CLIENT)
public class BloodStainParticle extends class_4003 {
    private final boolean permanent;

    public BloodStainParticle(class_638 world, double x, double y, double z, class_4002 spriteProvider, boolean permanent) {
        super(world, x, y, z, 0.0D, 0.0D, 0.0D);
        this.permanent = permanent;
        this.field_28786 = 0.0f;
        this.field_3844 = 0.0f;
        this.method_3084(BloodConstants.BLOOD_RED, BloodConstants.BLOOD_GREEN, BloodConstants.BLOOD_BLUE);
        this.field_17867 = 0.6f + this.field_3840.method_43057() * 0.6f;
        this.field_3847 = permanent ? 2000000000 : 6000;
        this.method_18140(spriteProvider);
    }

    @Override
    public void method_3074(class_4588 vertexConsumer, class_4184 camera, float tickDelta) {
        class_243 cameraPos = camera.method_19326();
        float x = (float) (class_3532.method_16436(tickDelta, this.field_3858, this.field_3874) - cameraPos.method_10216());
        float y = (float) (class_3532.method_16436(tickDelta, this.field_3838, this.field_3854) - cameraPos.method_10214()) + 0.015f;
        float z = (float) (class_3532.method_16436(tickDelta, this.field_3856, this.field_3871) - cameraPos.method_10215());

        float size = this.method_18132(tickDelta);
        float uMin = this.method_18133();
        float uMax = this.method_18134();
        float vMin = this.method_18135();
        float vMax = this.method_18136();
        int light = this.method_3068(tickDelta);

        // Fade out alpha only if temporary and near end of life
        if (!permanent && this.field_3866 > this.field_3847 - 100) {
            this.field_3841 = Math.max(0.0f, (float) (this.field_3847 - this.field_3866) / 100.0f);
        } else {
            this.field_3841 = 1.0f;
        }

        // Lay flat on top face of the block
        vertexConsumer.method_22912(x - size, y, z - size).method_22913(uMin, vMin).method_22915(this.field_3861, this.field_3842, this.field_3859, this.field_3841).method_60803(light);
        vertexConsumer.method_22912(x - size, y, z + size).method_22913(uMin, vMax).method_22915(this.field_3861, this.field_3842, this.field_3859, this.field_3841).method_60803(light);
        vertexConsumer.method_22912(x + size, y, z + size).method_22913(uMax, vMax).method_22915(this.field_3861, this.field_3842, this.field_3859, this.field_3841).method_60803(light);
        vertexConsumer.method_22912(x + size, y, z - size).method_22913(uMax, vMin).method_22915(this.field_3861, this.field_3842, this.field_3859, this.field_3841).method_60803(light);
    }

    @Override
    public class_3999 method_18122() {
        return class_3999.field_17829;
    }

    @Environment(EnvType.CLIENT)
    public static class Factory implements class_707<class_2400> {
        private final class_4002 spriteProvider;
        private final boolean permanent;

        public Factory(class_4002 spriteProvider, boolean permanent) {
            this.spriteProvider = spriteProvider;
            this.permanent = permanent;
        }

        @Override
        public class_703 createParticle(class_2400 type, class_638 world, double x, double y, double z, double velocityX, double velocityY, double velocityZ) {
            return new BloodStainParticle(world, x, y, z, this.spriteProvider, this.permanent);
        }
    }
}
