package net.anatomyblood.particle;

import net.anatomyblood.util.BloodConstants;
import net.fabricmc.fabric.api.particle.v1.FabricParticleTypes;
import net.minecraft.class_2378;
import net.minecraft.class_2400;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class ModParticles {
    public static final class_2400 BLOOD_DRIP = FabricParticleTypes.simple();
    public static final class_2400 BLOOD_SPLASH = FabricParticleTypes.simple();
    public static final class_2400 BLOOD_STAIN_PERMANENT = FabricParticleTypes.simple();
    public static final class_2400 BLOOD_STAIN_TEMPORARY = FabricParticleTypes.simple();

    public static void registerParticles() {
        class_2378.method_10230(class_7923.field_41180, class_2960.method_60655(BloodConstants.MOD_ID, "blood_drip"), BLOOD_DRIP);
        class_2378.method_10230(class_7923.field_41180, class_2960.method_60655(BloodConstants.MOD_ID, "blood_splash"), BLOOD_SPLASH);
        class_2378.method_10230(class_7923.field_41180, class_2960.method_60655(BloodConstants.MOD_ID, "blood_stain_permanent"), BLOOD_STAIN_PERMANENT);
        class_2378.method_10230(class_7923.field_41180, class_2960.method_60655(BloodConstants.MOD_ID, "blood_stain_temporary"), BLOOD_STAIN_TEMPORARY);
        BloodConstants.LOGGER.info("Registered Anatomy of Blood particles (#F0509A).");
    }
}
