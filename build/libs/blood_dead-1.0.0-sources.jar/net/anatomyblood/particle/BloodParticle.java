package net.anatomyblood.particle;

import net.anatomyblood.util.BloodConstants;
import net.minecraft.class_3999;
import net.minecraft.class_4002;
import net.minecraft.class_4003;
import net.minecraft.class_638;

public class BloodParticle extends class_4003 {

    public BloodParticle(class_638 world, double x, double y, double z, double velocityX, double velocityY, double velocityZ, class_4002 spriteProvider, boolean splash) {
        super(world, x, y, z, velocityX, velocityY, velocityZ);
        
        this.field_28786 = 0.88f;
        this.field_3852 = velocityX + (this.field_3840.method_43058() - 0.5D) * 0.1D;
        this.field_3869 = velocityY + (splash ? (this.field_3840.method_43058() * 0.15D) : -0.02D);
        this.field_3850 = velocityZ + (this.field_3840.method_43058() - 0.5D) * 0.1D;

        // Set Blood Color #F0509A
        this.method_3084(BloodConstants.BLOOD_RED, BloodConstants.BLOOD_GREEN, BloodConstants.BLOOD_BLUE);

        this.field_17867 = splash ? (0.18f + this.field_3840.method_43057() * 0.12f) : (0.12f + this.field_3840.method_43057() * 0.08f);
        this.field_3847 = 25 + this.field_3840.method_43048(25);
        this.field_3844 = splash ? 0.9f : 0.6f;

        this.method_18140(spriteProvider);
    }

    @Override
    public void method_3070() {
        super.method_3070();
        // Fade out alpha as particle ages
        this.field_3841 = Math.max(0.0f, 1.0f - ((float) this.field_3866 / (float) this.field_3847));
    }

    @Override
    public class_3999 method_18122() {
        return class_3999.field_17829;
    }
}
