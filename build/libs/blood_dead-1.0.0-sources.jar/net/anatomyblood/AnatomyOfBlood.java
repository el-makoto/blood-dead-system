package net.anatomyblood;

import net.anatomyblood.entity.ModEntities;
import net.anatomyblood.particle.ModParticles;
import net.anatomyblood.util.BloodConstants;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.gamerule.v1.GameRuleFactory;
import net.fabricmc.fabric.api.gamerule.v1.GameRuleRegistry;
import net.minecraft.class_1928;
import net.minecraft.class_3218;

public class AnatomyOfBlood implements ModInitializer {
    public static class_1928.class_4313<class_1928.class_4310> PERSIST_CORPSE_ON_RESPAWN;
    public static class_1928.class_4313<class_1928.class_4310> DESPAWN_BLOOD;

    @Override
    public void onInitialize() {
        BloodConstants.LOGGER.info("Initializing Anatomy of Blood (anatomy_blood)...");

        PERSIST_CORPSE_ON_RESPAWN = GameRuleRegistry.register(
                "anatomyBloodPersistCorpseOnRespawn",
                class_1928.class_5198.field_24094,
                GameRuleFactory.createBooleanRule(true)
        );

        DESPAWN_BLOOD = GameRuleRegistry.register(
                "anatomyBloodDespawnBlood",
                class_1928.class_5198.field_24094,
                GameRuleFactory.createBooleanRule(false)
        );

        ModParticles.registerParticles();
        ModEntities.registerEntities();
        net.anatomyblood.physics.JoltManager.init();

        BloodConstants.LOGGER.info("Anatomy of Blood initialized successfully.");
    }

    public static boolean shouldPersistCorpse(class_3218 world) {
        if (world == null || PERSIST_CORPSE_ON_RESPAWN == null) return true;
        try {
            class_1928.class_4310 rule = world.method_64395().method_20746(PERSIST_CORPSE_ON_RESPAWN);
            return rule != null ? rule.method_20753() : true;
        } catch (Exception e) {
            return true;
        }
    }

    public static boolean shouldDespawnBlood(class_3218 world) {
        if (world == null || DESPAWN_BLOOD == null) return false;
        try {
            class_1928.class_4310 rule = world.method_64395().method_20746(DESPAWN_BLOOD);
            return rule != null ? rule.method_20753() : false;
        } catch (Exception e) {
            return false;
        }
    }
}
